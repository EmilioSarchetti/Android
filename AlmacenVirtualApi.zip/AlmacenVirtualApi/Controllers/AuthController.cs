using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AlmacenVirtualApi.Data;
using AlmacenVirtualApi.Models;
using BCrypt.Net;

namespace AlmacenVirtualApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly AppDbContext _context;

        public AuthController(AppDbContext context)
        {
            _context = context;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Usuario usuario)
        {
            if (await _context.Usuarios.AnyAsync(u => u.Name_Usuario == usuario.Name_Usuario))
                return BadRequest("El nombre de usuario ya está en uso.");

            // Usar BCrypt para hashear la contraseña
            usuario.Contrasena = BCrypt.Net.BCrypt.HashPassword(usuario.Contrasena);
            _context.Usuarios.Add(usuario);
            await _context.SaveChangesAsync();

            return Ok("Usuario registrado correctamente.");
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Usuario usuarioLogin)
        {
            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(u => u.Name_Usuario == usuarioLogin.Name_Usuario);

            if (usuario == null || !BCrypt.Net.BCrypt.Verify(usuarioLogin.Contrasena, usuario.Contrasena))
                return Unauthorized("Credenciales inválidas.");

            return Ok(new { mensaje = "Login exitoso", usuario_id = usuario.Id });
        }
    }
}
