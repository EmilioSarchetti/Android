using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AlmacenVirtualApi.Data;
using AlmacenVirtualApi.Models;

namespace AlmacenVirtualApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductoController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProductoController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet("{usuarioId}")]
        public async Task<IActionResult> GetProductos(int usuarioId)
        {
            var productos = await _context.Productos
                .Where(p => p.UsuarioId == usuarioId)
                .ToListAsync();

            return Ok(productos);
        }

        [HttpGet("detalle/{id}")]
        public async Task<IActionResult> GetProducto(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            return producto == null ? NotFound() : Ok(producto);
        }

        [HttpPost("crear")]
public async Task<IActionResult> CrearProductoConImagen(
    [FromForm] string nombre,
    [FromForm] int cantidad,
    [FromForm] string categoria,
    [FromForm] int usuarioId,
    [FromForm] IFormFile? imagen)
{
    try
    {
        var categoriasValidas = new List<string>
        {
            "LIMPIEZA", "CUIDADO PERSONAL", "CARNES", "VERDURAS",
            "HARINAS", "NO PERECEDEROS", "CONDIMENTOS", "OTROS"
        };

        if (!categoriasValidas.Contains(categoria))
            return BadRequest("Categoría inválida.");

        string? imagenUrl = null;

        if (imagen != null && imagen.Length > 0)
        {
            var uploads = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
            if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);

            var nombreArchivo = Guid.NewGuid() + Path.GetExtension(imagen.FileName);
            var rutaCompleta = Path.Combine(uploads, nombreArchivo);

            using var stream = new FileStream(rutaCompleta, FileMode.Create);
            await imagen.CopyToAsync(stream);

            var baseUrl = "http://192.168.1.102:5046";
            imagenUrl = $"{baseUrl}/uploads/{nombreArchivo}";
        }

        var producto = new Producto
        {
            Nombre = nombre,
            Cantidad = cantidad,
            Categoria = categoria,
            UsuarioId = usuarioId,
            ImagenUrl = imagenUrl,
            Favorito = false
        };

        _context.Productos.Add(producto);
        await _context.SaveChangesAsync();

        return Ok(producto);
    }
    catch (Exception ex)
    {
        Console.WriteLine($"ERROR al crear producto: {ex.Message}");
        return StatusCode(500, "Error interno al crear producto");
    }
}

[HttpPut("editar/{id}")]
[Consumes("multipart/form-data")]
public async Task<IActionResult> ActualizarProductoConImagen(
    int id,
    [FromForm] string nombre,
    [FromForm] int cantidad,
    [FromForm] string categoria,
    [FromForm] IFormFile? imagen)
{
    var producto = await _context.Productos.FindAsync(id);
    if (producto == null) return NotFound();

    producto.Nombre = nombre;
    producto.Cantidad = cantidad;
    producto.Categoria = categoria;

    if (imagen != null && imagen.Length > 0)
    {
        var uploads = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/uploads");
        if (!Directory.Exists(uploads)) Directory.CreateDirectory(uploads);

        var nombreArchivo = Guid.NewGuid() + Path.GetExtension(imagen.FileName);
        var rutaCompleta = Path.Combine(uploads, nombreArchivo);

        using var stream = new FileStream(rutaCompleta, FileMode.Create);
        await imagen.CopyToAsync(stream);

        var baseUrl = $"{Request.Scheme}://{Request.Host}";
producto.ImagenUrl = $"{baseUrl}/uploads/{nombreArchivo}";

    }

    // Si no hay imagen nueva, se conserva la anterior

    await _context.SaveChangesAsync();
    return Ok(producto);
}


        [HttpDelete("{id}")]
        public async Task<IActionResult> EliminarProducto(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            if (producto == null) return NotFound();

            _context.Productos.Remove(producto);
            await _context.SaveChangesAsync();
            return Ok("Producto eliminado.");
        }
    }
}
