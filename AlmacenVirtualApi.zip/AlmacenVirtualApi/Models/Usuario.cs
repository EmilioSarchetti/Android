using System.Collections.Generic;

namespace AlmacenVirtualApi.Models
{
    public class Usuario
    {
        public int Id { get; set; }
        public string Name_Usuario { get; set; } = string.Empty;
        public string Contrasena { get; set; } = string.Empty;

        // Agregar la relación inversa
        public ICollection<Producto> Productos { get; set; } = new List<Producto>();
    }
}
