using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AlmacenVirtualApi.Models
{
    public class Producto
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Nombre { get; set; } = string.Empty;  // Ya coincide con DB

        public int Cantidad { get; set; }

        public string? ImagenUrl { get; set; }  // Ya coincide con DB

        public bool Favorito { get; set; }

        [Required]
        public string Categoria { get; set; } = string.Empty;  // Ya coincide con DB

        public int UsuarioId { get; set; }  // Ya coincide con DB

        [ForeignKey("UsuarioId")]
        public Usuario? Usuario { get; set; }
    }
}
